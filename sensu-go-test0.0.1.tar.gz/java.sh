#!/bin/sh
ps -ef | grep nginx | grep -v grep > test1.txt

if [ -s test1.txt ] ; then
#STRING="PopularNewsWebservice.txt"

#echo $STRING

#if [ $? -eq 0 ]; then
    exit 0
else
    exit 2
fi
